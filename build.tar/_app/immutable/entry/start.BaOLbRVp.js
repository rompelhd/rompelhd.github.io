import{a as t}from"../chunks/entry.BX7HH_UX.js";export{t as start};
